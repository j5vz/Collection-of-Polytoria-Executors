New version dropped, heres the readme:
Switched injecttion method to a LdrLoadDll stub, this should flag revival anticheats less often. If you get flagged by castle.dll aka Austiblox's AC inject using xenos with manual map + erase pe, havent tested detections on austiblox since i dont have a working account right now.
Ferns.club/0.477 support added! You can use this on any revival using 0.477/May 3 2021 too.
Pekora 2020 support rebranded to 2020L support, this is because pedone doesnt use 0.450 anymore and a lot of other revivals use it still.
Carbon 2020 and RFD 2020L support added to the built in injector.
If you have any troubles message me @scamnapse on discord or join my discord server if you're not already in it.
https://discord.gg/49DF9VnfTq <- Discord Server